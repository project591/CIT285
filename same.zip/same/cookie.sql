
DROP DATABASE IF EXISTS mock;
--
-- Create a new database.
CREATE DATABASE IF NOT EXISTS mock;
USE mock;
--
--
-- Create tables in book_store database.
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS user;

-- The products will be books in this example
create table products (id varchar (30) not null, product varchar(30), price int );

create table user (UserID INT NOT NULL AUTO_INCREMENT,firstname VARCHAR(100) NOT NULL, lastname VARCHAR(100) NOT NULL, 
password VARCHAR(100) NOT NULL, email varchar(60), PRIMARY KEY(UserID));

-- The not null auto increment might give you problems. -- Maybe delete that and leave it as simply normal when testing the program out. 
create table orders(UserEmail VARCHAR(30),
                    productid VARCHAR(30),
                    quantity int,
                    total int
                    );
                    
insert into user (UserID,firstname, lastname, password, email)
values('1','Alex', 'Gonzalez', 'goodyear', 'ag52@gmail.com');

insert into user (UserID,firstname, lastname, password, email)
values('2','Ernesto', 'Valverde', 'goodyear', 'gw52@gmail.com');

insert into products (id, product, price)
values('1', 'Harry Potter', 3);

insert into products (id, product, price)
values('2', 'Lord Of the Flies', 5);

insert into products (id, product, price)
values('3', 'The Count of Monte Cristo', 5);





