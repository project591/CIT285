package login;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@SuppressWarnings("unused")
@WebServlet("/Login")
public class Login extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
// Need to modify here. Is it connected to the LoginDAO
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
      String email = request.getParameter("email");
      String password = request.getParameter("password");
      
      //How could I store this in the database      
      
      LoginDAO userDao = new LoginDAO();      
      
      PrintWriter out=response.getWriter();
      Cookie ck=new Cookie("auth", email);
      ck.setMaxAge(600);
      
	try {

	LoginClass user = userDao.checkLogin(email, password);
	
       if(user != null)
      {
         response.addCookie(ck);
         response.sendRedirect("home.jsp");
         
	    PrintWriter pwriter = response.getWriter();
	    System.out.println("This is from the Login Servlet: " + email);
	    // pwriter.print("Name: "+ck.getName()); 
         return;
      }
      else
      {
         RequestDispatcher rd = request.getRequestDispatcher("login.html");
          out.println("<font color=red>Either user name or password is wrong.</font>");
          rd.include(request, response);
      }}
     
       
       catch (SQLException | ClassNotFoundException ex) {
			throw new ServletException(ex);
     
	}      
  }}

