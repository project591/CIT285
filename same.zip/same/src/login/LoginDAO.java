package login;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class LoginDAO {

	public LoginClass checkLogin(String email, String password) throws SQLException, 
			ClassNotFoundException {
		String jdbcURL = "jdbc:mysql://localhost/mock";
		String dbUser = "root";
		String dbPassword = "root45&";
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		
		Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
		System.out.println("Connection: " + connection);
		String sql = "SELECT * FROM user WHERE email = ? and password = ?";
		
		PreparedStatement statement = connection.prepareStatement(sql);
		statement.setString(1, email);
		statement.setString(2, password);
		
		ResultSet result = statement.executeQuery();
		
		LoginClass user = null;

		if (result.next()) {
			user = new LoginClass();
			user.setEmail(email);
		}
		
		connection.close();

		return user;
	}
}

