package login;

public class LoginClass {
	
	private int id;
	private String firstname;
	private static String email; // Will be used to store databse with  persons prodcut
	private String password;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullname() {
		return firstname;
	}

	public void setFullname(String fullname) {
		this.firstname = fullname;
	}

	public static String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		LoginClass.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
