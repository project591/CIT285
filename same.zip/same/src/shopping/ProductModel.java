package shopping;

// Will attempt to connect to the database here. 

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class ProductModel {

	public List<Product> products;

	public ProductModel() {
		// try leaving the line below intact.
		this.products = new ArrayList<Product>();
		
		 try {
	            // Step 1: Load the JDBC driver. jdbc:mysql://localhost:3306/travel
	            Class.forName("com.mysql.jdbc.Driver");
	 
	            // Step 2: Establish the connection to the database.
	            String url = "jdbc:mysql://localhost/mock"; // create database
	            Connection conn = DriverManager.getConnection(url, "root", "root45&");
	            Statement st = conn.createStatement();
	            ResultSet srs = st.executeQuery("SELECT * FROM products");
	            while (srs.next()) {
	                Product product = new Product();
	                product.setId(srs.getString("id"));
	                product.setName(srs.getString("product"));
	                product.setPrice(srs.getInt("price"));
	                products.add(product);    }	       	                     
	 
	        //System.out.println(namelist.);
	        } catch (Exception e) {
	            System.err.println("Got an exception! ");
	            System.err.println(e.getMessage());
	        }
	    }
		
	// Might need to change how this works
	public List<Product> findAll() {
		return this.products;
	}

	public Product find(String id) {
		for (Product product : this.products) {
			if (product.getId().equalsIgnoreCase(id)) {
				return product;
			}
		}
		return null;
	}

}