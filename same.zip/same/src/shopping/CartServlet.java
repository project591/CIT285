package shopping;
import  login.*;
import java.io.Serializable;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

@SuppressWarnings("unused")
@WebServlet("/cart")
public class CartServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
	@SuppressWarnings("unused")
	private PreparedStatement pst;

	public CartServlet() {
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String action = request.getParameter("action");
		if (action == null) {
			doGet_DisplayCart(request, response);
			@SuppressWarnings("unused")
			String strQuantity = request.getParameter("quantity"); // does nothing
		} else {
			if (action.equalsIgnoreCase("buy")) {
				try {
					doGet_Buy(request, response);
				} catch (SQLException | ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			} else if (action.equalsIgnoreCase("remove")) {
				doGet_Remove(request, response);
			}
		}
	}

	protected void doGet_DisplayCart(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("cart.jsp").forward(request, response);
	}

	protected void doGet_Remove(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session = request.getSession();
		@SuppressWarnings("unchecked")
		List<Item> cart = (List<Item>) session.getAttribute("cart");
		int index = isExisting(request.getParameter("id"), cart);
		cart.remove(index);
		session.setAttribute("cart", cart);
		response.sendRedirect("cart");
	}
	
	@SuppressWarnings("null")
	protected void doGet_Buy(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, SQLException, ClassNotFoundException {
		ProductModel productModel = new ProductModel(); // What to do with this. 
		HttpSession session = request.getSession();
		// If the cart is empty
		if (session.getAttribute("cart") == null) {
			List<Item> cart = new ArrayList<Item>();
						
			cart.add(new Item(productModel.find(request.getParameter("id")), 1));
			// The one would be the quantity
			session.setAttribute("cart", cart);	
			
			int index = isExisting(request.getParameter("id"), cart);
			
			int quantity = cart.get(index).getQuantity();
			cart.get(index).setQuantity(quantity);	
			
			Class.forName("com.mysql.jdbc.Driver");			
			PreparedStatement pst;
            String url = "jdbc:mysql://localhost/mock"; // create database
            Connection conn = DriverManager.getConnection(url, "root", "root45&");
            String query = "Insert into orders(UserEmail,productid, quantity,total) values(?,?,?,?)";
			pst = conn.prepareStatement(query);
			productModel.find(request.getParameter("id"));
			// Need to somehow get the id
			String willItWork = request.getParameter("id");
			
			int price44 = cart.get(index).getProduct().getPrice();
			cart.get(index).getProduct().setPrice(price44);			
			
			System.out.println("Trying to print the price: " + 	price44);			
						
			// Maybe add the value to a new array list. And use the same index as 		
			
		    //System.out.println("First element of the ArrayList: " + strike.getPrice());
						
			//System.out.println("This would be the price: " + price);				
					
			int total = price44 * quantity;
							
			String username = LoginClass.getEmail();				
			
			pst.setString(1, username);	
			pst.setString(2, willItWork);	
			pst.setInt(3, (index + 1)); //working with the index
			pst.setInt(4,  total );
			pst.executeUpdate();
			
			// This is where you will need to insert to the values into the database
		} else {
				            
			@SuppressWarnings("unchecked")
			List<Item> cart = (List<Item>) session.getAttribute("cart");
			// This section of the code is already working with the product model
			int index = isExisting(request.getParameter("id"), cart);
			if (index == -1) {
				
			cart.add(new Item(productModel.find(request.getParameter("id")), 1));			
						
			} else {
				int quantity = cart.get(index).getQuantity() + 1;
				cart.get(index).setQuantity(quantity);	
				
				Class.forName("com.mysql.jdbc.Driver");
				
				PreparedStatement pst;
	            String url = "jdbc:mysql://localhost/mock"; // connect to database
	            Connection conn = DriverManager.getConnection(url, "root", "root45&");
	            String query = "Insert into orders(UserEmail,productid, quantity, total) values(?,?,?,?)";
				pst = conn.prepareStatement(query);
	            
				String id = request.getParameter("id");		
				//String quantity1 = request.getParameter("quantity");				
				
				String username = LoginClass.getEmail();
				
				int price44 = cart.get(index).getProduct().getPrice() ;
				cart.get(index).getProduct().setPrice(price44);	
				
				
				int total =  price44 * quantity ;
				// Need to find a way to keep adding the total's. Need to store them somewhere and add them and 
				// Try to get everything in a vector and if you can add them up.
				// Vectors should make things more easier. 							
				
				pst.setString(1, username);	
				pst.setString(2, id);	
				pst.setInt(3, quantity);
				pst.setInt(4,  total );
				pst.executeUpdate();
			}								
		}
		
		response.sendRedirect("cart");	}	

	private int isExisting(String id, List<Item> cart) {
		for (int i = 0; i < cart.size(); i++) {
			if (cart.get(i).getProduct().getId().equalsIgnoreCase(id)) {
				return i;
			}			
		}
		return -1;
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException{		
	}
}
